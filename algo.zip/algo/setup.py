"""Setup script for algo_lib package."""

from setuptools import setup, find_packages

setup(
    name="algo_lib",
    version="1.0.0",
    description=(
        "Bibliothèque d'algorithmes classiques — "
        "TP Algorithmique avancée (arbres binaires, structures linéaires, matrices)"
    ),
    author="Pierre Montaret",
    packages=find_packages(),
    python_requires=">=3.10",
    extras_require={
        "dev": [
            "pytest>=8.0.0",
            "pytest-cov>=4.1.0",
            "pylint>=3.0.0",
            "flake8>=7.0.0",
        ],
    },
)
