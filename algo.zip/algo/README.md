# 🧠 Environnement de Développement Python ML/DL

Environnement de développement complet pour le Machine Learning et le Deep Learning, incluant la bibliothèque d'algorithmes du TP d'Algorithmique avancée (`algo_lib`) et des outils de vérification de la qualité du code. Le tout containerisé avec Docker.

## 📦 Contenu

### Bibliothèques ML/DL
| Bibliothèque | Catégorie |
|---|---|
| scikit-learn | ML classique (classification, régression, clustering) |
| TensorFlow + Keras | Deep Learning (Google) |
| PyTorch | Deep Learning (Meta) |
| XGBoost | Gradient Boosting |
| NumPy / SciPy | Calculs scientifiques |
| Pandas | Manipulation de données |
| Matplotlib / Seaborn | Visualisation |
| Jupyter Lab | Notebooks interactifs |

### Bibliothèque `algo_lib` (TP Algorithmique avancée)
| Module | Contenu |
|---|---|
| `binary_trees` | Arbre binaire, parcours BFS / pré / in / postfixe, insertion feuille & branche |
| `linear_structures` | Pile (Stack), File (Queue), Liste chaînée (LinkedList) |
| `matrices` | Création n×m, addition, multiplication, opérations élément par élément (+, -, ×, /) |

### Outils de qualité du code
| Outil | Type | Rôle |
|---|---|---|
| Pylint | Analyse statique | Style, erreurs, conventions |
| Flake8 | Analyse statique | Linting rapide PEP8 |
| Bandit | Sécurité | Détection de vulnérabilités |
| Radon | Complexité | Complexité cyclomatique |
| Xenon | Complexité | Seuils de complexité |
| YAPF | Formatage | Auto-formatage Google style |
| pytest + coverage | Test dynamique | Tests unitaires + couverture |

## 🚀 Démarrage rapide

### Avec Docker (recommandé)
```bash
# Lancer le script de déploiement
chmod +x scripts/deploy.sh
./scripts/deploy.sh

# Ou manuellement
docker compose up -d

# Accéder à Jupyter Lab
# → http://localhost:8888
```

### Sans Docker (installation locale)
```bash
# Créer un environnement virtuel
python3 -m venv .venv
source .venv/bin/activate

# Installer les dépendances
make install
```

## 🔧 Commandes utiles

```bash
make help         # Affiche toutes les commandes disponibles
make install      # Installe les dépendances + algo_lib
make lint         # Analyse statique (Pylint + Flake8)
make security     # Analyse de sécurité (Bandit)
make complexity   # Mesure de complexité (Radon + Xenon)
make format       # Auto-formatage (YAPF)
make test         # Tests unitaires avec couverture
make quality      # Tous les checks d'un coup
make clean        # Nettoyage des fichiers générés
```

### Dans le conteneur Docker
```bash
docker compose exec ml-env make quality
docker compose exec ml-env make test
docker compose exec ml-env bash
```

## 📁 Structure du projet

```
algo/
├── Dockerfile              # Image Docker
├── docker-compose.yml      # Orchestration
├── requirements.txt        # Dépendances Python
├── setup.py                # Installation du package
├── pyproject.toml           # Configuration des outils
├── Makefile                # Commandes utilitaires
├── README.md               # Cette documentation
├── binary_trees.py         # (source originale TP)
├── linear_structures.py    # (source originale TP)
├── matrices.py             # (source originale TP)
├── main.py                 # (tests manuels originaux TP)
├── algo_lib/               # Package installable
│   ├── __init__.py
│   ├── binary_trees.py
│   ├── linear_structures.py
│   └── matrices.py
├── tests/                  # Tests unitaires
│   └── test_algo_lib.py
├── notebooks/              # Notebooks Jupyter
│   └── demo_ml.ipynb
└── scripts/
    └── deploy.sh           # Script de déploiement
```

## 👥 Auteurs

- Pierre Montaret

## 📝 Licence

Projet académique — GES 2025-2026
