import algo_lib.binary_trees as bt
import algo_lib.linear_structures as ls
import algo_lib.matrices as mat

def test_binary_trees():
    print("--- Test de l'API des Arbres Binaires ---\n")
    
    print("1. Création d'un arbre binaire à 7 sommets...")
    tree = bt.create_binary_tree(7)
    
    print(f"Parcours en largeur (Breadth-first): {bt.breadth_first_search(tree)}")
    print(f"Parcours préfixe (Pre-order):        {bt.pre_order(tree)}")
    print(f"Parcours infixe (In-order):          {bt.in_order(tree)}")
    print(f"Parcours postfixe (Post-order):      {bt.post_order(tree)}")
    
    print("\n2. Insertion d'une feuille Node(99) à gauche de Node(4)...")
    success = bt.insert_leaf(tree, 4, 99, 'left')
    print(f"Insertion réussie : {success}")
    print(f"Parcours en largeur après insertion : {bt.breadth_first_search(tree)}")
    
    print("\n3. Insertion d'une branche à droite de Node(4)...")
    branch_root = bt.Node(100)
    branch_root.left = bt.Node(101)
    
    success_branch = bt.insert_branch(tree, 4, branch_root, 'right')
    print(f"Insertion de la branche réussie : {success_branch}")
    print(f"Parcours en largeur après insertion de la branche : {bt.breadth_first_search(tree)}")
    print("\n" + "="*40 + "\n")


def test_linear_structures():
    print("--- Test de l'API des Structures Linéaires ---\n")
    
    print("Test de la Pile (Stack) :")
    s = ls.Stack()
    s.push(10)
    s.push(20)
    s.push(30)
    print(f"État initial de la pile : {s}")
    print(f"Dépiler (Pop) : {s.pop()}")
    print(f"Pile après dépilage : {s}")
    print(f"Recherche de 10 : {s.search(10)}")
    print(f"Est vide ? : {s.is_empty()}")
    
    print("\nTest de la File (Queue) :")
    q = ls.Queue()
    q.enqueue("Alice")
    q.enqueue("Bob")
    q.enqueue("Charlie")
    print(f"État initial de la file : {q}")
    print(f"Retirer (Dequeue) : {q.dequeue()}")
    print(f"File après retrait : {q}")
    print(f"Recherche de 'Charlie' : {q.search('Charlie')}")
    print(f"Est vide ? : {q.is_empty()}")

    print("\nTest de la Liste Chaînée (LinkedList) :")
    ll = ls.LinkedList()
    ll.insert("A")
    ll.insert("B")
    ll.insert("C")
    print(f"État initial de la liste chaînée : {ll}")
    ll.insert("X", 1)
    print(f"Après insertion de 'X' à la position 1 : {ll}")
    print(f"Recherche de 'X' (retourne sa position) : {ll.search('X')}")
    ll.delete("B")
    print(f"Après suppression de 'B' : {ll}")
    print("\n" + "="*40 + "\n")


def test_matrices():
    print("--- Test de l'API des Matrices ---\n")
    
    print("1. Création d'une matrice 5x4 initialisée :")
    m5x4 = mat.create_5x4_matrix()
    mat.print_matrix(m5x4)
    print("\n")
    
    mat1 = [[10, 20], [30, 40]]
    mat2 = [[2, 4], [0, 5]]
    
    print("Matrice 1 :")
    mat.print_matrix(mat1)
    print("Matrice 2 :")
    mat.print_matrix(mat2)
    
    print("\nTest de l'Opération (+) :")
    res_add = mat.apply_operation(mat1, mat2, '+')
    mat.print_matrix(res_add)
    
    print("\nTest de l'Opération (-) :")
    res_sub = mat.apply_operation(mat1, mat2, '-')
    mat.print_matrix(res_sub)
    
    print("\nTest de la Division standard (/) avec la règle spéciale (/0 -> = 1) :")
    res_div = mat.apply_operation(mat1, mat2, '/')
    mat.print_matrix(res_div)
    
    print("\nTest de la Multiplication standard de matrices :")
    res_mult = mat.multiply_matrices(mat1, mat2)
    mat.print_matrix(res_mult)
    print("\n" + "="*40 + "\n")


if __name__ == "__main__":
    test_binary_trees()
    test_linear_structures()
    test_matrices()
    print("Tous les tests des modules ont été complétés avec succès !")
