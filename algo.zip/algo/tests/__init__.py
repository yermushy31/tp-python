"""Package de tests pour algo_lib."""
