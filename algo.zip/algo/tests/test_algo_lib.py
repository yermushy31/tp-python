"""
Tests unitaires pour algo_lib.

Teste les trois modules du TP Algorithmique avancée :
- binary_trees    : Arbre binaire et parcours
- linear_structures : Pile, File, Liste chaînée
- matrices        : Opérations matricielles
"""

import pytest
from algo_lib.binary_trees import (
    Node, create_binary_tree, breadth_first_search,
    pre_order, in_order, post_order,
    insert_leaf, insert_branch,
)
from algo_lib.linear_structures import Stack, Queue, LinkedList
from algo_lib.matrices import (
    create_5x4_matrix, create_nxm_matrix,
    are_identically_shaped, can_be_multiplied,
    add_matrices, multiply_matrices, apply_operation,
)


# ═══════════════════════════════════════════════════════════════════════════════
# Tests — Binary Trees
# ═══════════════════════════════════════════════════════════════════════════════

class TestBinaryTreeCreation:
    """Tests de création d'arbres binaires."""

    def test_create_tree_7_nodes(self):
        root = create_binary_tree(7)
        assert root is not None
        assert root.value == 1
        assert root.left.value == 2
        assert root.right.value == 3

    def test_create_tree_single_node(self):
        root = create_binary_tree(1)
        assert root.value == 1
        assert root.left is None
        assert root.right is None

    def test_create_tree_zero(self):
        assert create_binary_tree(0) is None

    def test_create_tree_negative(self):
        assert create_binary_tree(-5) is None


class TestBinaryTreeTraversals:
    """Tests des parcours d'arbre."""

    @pytest.fixture
    def tree_7(self):
        return create_binary_tree(7)

    def test_breadth_first_search(self, tree_7):
        result = breadth_first_search(tree_7)
        assert result == [1, 2, 3, 4, 5, 6, 7]

    def test_bfs_empty(self):
        assert breadth_first_search(None) == []

    def test_pre_order(self, tree_7):
        result = pre_order(tree_7)
        assert result == [1, 2, 4, 5, 3, 6, 7]

    def test_pre_order_empty(self):
        assert pre_order(None) == []

    def test_in_order(self, tree_7):
        result = in_order(tree_7)
        assert result == [4, 2, 5, 1, 6, 3, 7]

    def test_in_order_empty(self):
        assert in_order(None) == []

    def test_post_order(self, tree_7):
        result = post_order(tree_7)
        assert result == [4, 5, 2, 6, 7, 3, 1]

    def test_post_order_empty(self):
        assert post_order(None) == []


class TestBinaryTreeInsertions:
    """Tests d'insertion dans l'arbre."""

    def test_insert_leaf_success(self):
        root = create_binary_tree(3)
        # Node 2 a un enfant gauche? tree(3): 1 -> left=2, right=3, 2 -> left=None, right=None
        # Actually tree(3): node1.left=node2, node1.right=node3
        # node2: left_index=4 > 3, right_index=5 > 3 => no children
        result = insert_leaf(root, 2, 99, 'left')
        assert result is True
        assert breadth_first_search(root) == [1, 2, 3, 99]

    def test_insert_leaf_parent_not_found(self):
        root = create_binary_tree(3)
        result = insert_leaf(root, 999, 50, 'left')
        assert result is False

    def test_insert_leaf_position_taken(self):
        root = create_binary_tree(7)
        # Node 1 already has left child (node 2)
        result = insert_leaf(root, 1, 99, 'left')
        assert result is False

    def test_insert_leaf_on_none(self):
        assert insert_leaf(None, 1, 2, 'left') is False

    def test_insert_branch_success(self):
        root = create_binary_tree(3)
        branch = Node(100)
        branch.left = Node(101)
        result = insert_branch(root, 2, branch, 'right')
        assert result is True
        assert 100 in breadth_first_search(root)
        assert 101 in breadth_first_search(root)

    def test_insert_branch_parent_not_found(self):
        root = create_binary_tree(3)
        branch = Node(100)
        result = insert_branch(root, 999, branch, 'left')
        assert result is False

    def test_insert_branch_on_none(self):
        assert insert_branch(None, 1, Node(2), 'left') is False


# ═══════════════════════════════════════════════════════════════════════════════
# Tests — Linear Structures
# ═══════════════════════════════════════════════════════════════════════════════

class TestStack:
    """Tests de la Pile (Stack)."""

    def test_push_pop(self):
        s = Stack()
        s.push(10)
        s.push(20)
        s.push(30)
        assert s.pop() == 30
        assert s.pop() == 20
        assert s.pop() == 10

    def test_is_empty(self):
        s = Stack()
        assert s.is_empty() is True
        s.push(1)
        assert s.is_empty() is False

    def test_pop_empty_raises(self):
        s = Stack()
        with pytest.raises(IndexError):
            s.pop()

    def test_search(self):
        s = Stack()
        s.push(10)
        s.push(20)
        assert s.search(10) is True
        assert s.search(99) is False

    def test_repr(self):
        s = Stack()
        s.push(1)
        s.push(2)
        assert repr(s) == "Stack([1, 2])"


class TestQueue:
    """Tests de la File (Queue)."""

    def test_enqueue_dequeue(self):
        q = Queue()
        q.enqueue("Alice")
        q.enqueue("Bob")
        q.enqueue("Charlie")
        assert q.dequeue() == "Alice"
        assert q.dequeue() == "Bob"
        assert q.dequeue() == "Charlie"

    def test_is_empty(self):
        q = Queue()
        assert q.is_empty() is True
        q.enqueue(1)
        assert q.is_empty() is False

    def test_dequeue_empty_raises(self):
        q = Queue()
        with pytest.raises(IndexError):
            q.dequeue()

    def test_search(self):
        q = Queue()
        q.enqueue("A")
        q.enqueue("B")
        assert q.search("A") is True
        assert q.search("Z") is False

    def test_repr(self):
        q = Queue()
        q.enqueue(1)
        assert repr(q) == "Queue([1])"


class TestLinkedList:
    """Tests de la Liste chaînée (LinkedList)."""

    def test_insert_at_end(self):
        ll = LinkedList()
        ll.insert("A")
        ll.insert("B")
        ll.insert("C")
        assert repr(ll) == "A -> B -> C"

    def test_insert_at_position(self):
        ll = LinkedList()
        ll.insert("A")
        ll.insert("B")
        ll.insert("C")
        ll.insert("X", 1)
        assert repr(ll) == "A -> X -> B -> C"

    def test_insert_at_head(self):
        ll = LinkedList()
        ll.insert("B")
        ll.insert("A", 0)
        assert repr(ll) == "A -> B"

    def test_insert_out_of_bounds_raises(self):
        ll = LinkedList()
        with pytest.raises(IndexError):
            ll.insert("A", 5)

    def test_search_found(self):
        ll = LinkedList()
        ll.insert("A")
        ll.insert("B")
        ll.insert("C")
        assert ll.search("B") == 1

    def test_search_not_found(self):
        ll = LinkedList()
        ll.insert("A")
        assert ll.search("Z") == -1

    def test_delete_success(self):
        ll = LinkedList()
        ll.insert("A")
        ll.insert("B")
        ll.insert("C")
        assert ll.delete("B") is True
        assert repr(ll) == "A -> C"

    def test_delete_head(self):
        ll = LinkedList()
        ll.insert("A")
        ll.insert("B")
        assert ll.delete("A") is True
        assert repr(ll) == "B"

    def test_delete_not_found(self):
        ll = LinkedList()
        ll.insert("A")
        assert ll.delete("Z") is False

    def test_delete_from_empty(self):
        ll = LinkedList()
        assert ll.delete("A") is False

    def test_empty_repr(self):
        ll = LinkedList()
        assert repr(ll) == "Liste chaînée vide"


# ═══════════════════════════════════════════════════════════════════════════════
# Tests — Matrices
# ═══════════════════════════════════════════════════════════════════════════════

class TestMatrixCreation:
    """Tests de création de matrices."""

    def test_create_5x4(self):
        m = create_5x4_matrix()
        assert len(m) == 5
        assert all(len(row) == 4 for row in m)
        assert all(m[i][j] == 0 for i in range(5) for j in range(4))

    def test_create_nxm(self):
        m = create_nxm_matrix(3, 2)
        assert len(m) == 3
        assert all(len(row) == 2 for row in m)

    def test_create_nxm_invalid(self):
        assert create_nxm_matrix(0, 5) == []
        assert create_nxm_matrix(-1, 3) == []


class TestMatrixChecks:
    """Tests des vérifications de compatibilité."""

    def test_identical_shape_true(self):
        m1 = [[1, 2], [3, 4]]
        m2 = [[5, 6], [7, 8]]
        assert are_identically_shaped(m1, m2) is True

    def test_identical_shape_false(self):
        m1 = [[1, 2], [3, 4]]
        m2 = [[1, 2, 3]]
        assert are_identically_shaped(m1, m2) is False

    def test_identical_shape_empty(self):
        assert are_identically_shaped([], [[1]]) is False

    def test_can_multiply_true(self):
        m1 = [[1, 2, 3], [4, 5, 6]]  # 2x3
        m2 = [[1], [2], [3]]          # 3x1
        assert can_be_multiplied(m1, m2) is True

    def test_can_multiply_false(self):
        m1 = [[1, 2], [3, 4]]  # 2x2
        m2 = [[1, 2, 3]]       # 1x3
        assert can_be_multiplied(m1, m2) is False


class TestMatrixOperations:
    """Tests des opérations matricielles."""

    def test_add_matrices(self):
        m1 = [[10, 20], [30, 40]]
        m2 = [[2, 4], [0, 5]]
        result = add_matrices(m1, m2)
        assert result == [[12, 24], [30, 45]]

    def test_add_incompatible_raises(self):
        m1 = [[1, 2]]
        m2 = [[1], [2]]
        with pytest.raises(ValueError):
            add_matrices(m1, m2)

    def test_multiply_matrices(self):
        m1 = [[10, 20], [30, 40]]
        m2 = [[2, 4], [0, 5]]
        result = multiply_matrices(m1, m2)
        assert result == [[20, 140], [60, 320]]

    def test_multiply_incompatible_raises(self):
        m1 = [[1, 2]]      # 1x2
        m2 = [[1, 2, 3]]   # 1x3
        with pytest.raises(ValueError):
            multiply_matrices(m1, m2)

    def test_apply_add(self):
        m1 = [[1, 2], [3, 4]]
        m2 = [[5, 6], [7, 8]]
        result = apply_operation(m1, m2, '+')
        assert result == [[6, 8], [10, 12]]

    def test_apply_subtract(self):
        m1 = [[10, 20], [30, 40]]
        m2 = [[2, 4], [0, 5]]
        result = apply_operation(m1, m2, '-')
        assert result == [[8, 16], [30, 35]]

    def test_apply_multiply_elementwise(self):
        m1 = [[2, 3], [4, 5]]
        m2 = [[1, 2], [3, 4]]
        result = apply_operation(m1, m2, 'x')
        assert result == [[2, 6], [12, 20]]

    def test_apply_divide(self):
        m1 = [[10, 20], [30, 40]]
        m2 = [[2, 4], [5, 8]]
        result = apply_operation(m1, m2, '/')
        assert result == [[5.0, 5.0], [6.0, 5.0]]

    def test_apply_divide_by_zero_returns_1(self):
        """Règle spéciale : division par 0 → résultat = 1."""
        m1 = [[10, 20], [30, 40]]
        m2 = [[2, 0], [0, 5]]
        result = apply_operation(m1, m2, '/')
        assert result[0][1] == 1  # 20 / 0 = 1
        assert result[1][0] == 1  # 30 / 0 = 1

    def test_apply_invalid_operation_raises(self):
        m1 = [[1]]
        m2 = [[2]]
        with pytest.raises(ValueError):
            apply_operation(m1, m2, '%')

    def test_apply_incompatible_raises(self):
        m1 = [[1, 2]]
        m2 = [[1], [2]]
        with pytest.raises(ValueError):
            apply_operation(m1, m2, '+')
