"""
algo_lib — Bibliothèque d'algorithmes du TP Algorithmique avancée
=================================================================

Package regroupant les implémentations d'algorithmes et structures de données
développées dans le cadre du TP du cours d'Algorithmique avancée :

- **binary_trees**       : Arbres binaires, parcours (BFS, pré/in/postfixe),
                           insertion de feuilles et branches
- **linear_structures**  : Structures linéaires (Pile, File, Liste chaînée)
- **matrices**           : Opérations sur les matrices (création, addition,
                           multiplication, opérations élément par élément)
"""

__version__ = "1.0.0"
__author__ = "Pierre Montaret"

# Binary Trees
from algo_lib.binary_trees import (
    Node,
    create_binary_tree,
    breadth_first_search,
    pre_order,
    in_order,
    post_order,
    insert_leaf,
    insert_branch,
)

# Linear Structures
from algo_lib.linear_structures import (
    Stack,
    Queue,
    ListNode,
    LinkedList,
)

# Matrices
from algo_lib.matrices import (
    create_5x4_matrix,
    create_nxm_matrix,
    are_identically_shaped,
    can_be_multiplied,
    add_matrices,
    multiply_matrices,
    apply_operation,
    print_matrix,
)
