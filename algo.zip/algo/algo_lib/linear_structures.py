class Stack:
    """
    Représente une Pile (Stack) utilisant le principe LIFO (Dernier Entré, Premier Sorti).
    """
    def __init__(self):
        self.items = []

    def is_empty(self):
        """Pile-vide ?"""
        return len(self.items) == 0

    def push(self, element):
        """Empiler"""
        self.items.append(element)

    def pop(self):
        """Dépiler"""
        if self.is_empty():
            raise IndexError("Impossible de dépiler une pile vide")
        return self.items.pop()

    def search(self, element):
        """Rechercher un élément dans la pile"""
        return element in self.items

    def __repr__(self):
        return f"Stack({self.items})"


class Queue:
    """
    Représente une File (Queue) utilisant le principe FIFO (Premier Entré, Premier Sorti).
    """
    def __init__(self):
        self.items = []

    def is_empty(self):
        """File vide ?"""
        return len(self.items) == 0

    def enqueue(self, element):
        """Ajouter"""
        self.items.append(element)

    def dequeue(self):
        """Retirer"""
        if self.is_empty():
            raise IndexError("Impossible de retirer d'une file vide")
        return self.items.pop(0)

    def search(self, element):
        """Rechercher un élément dans la file"""
        return element in self.items

    def __repr__(self):
        return f"Queue({self.items})"


class ListNode:
    """
    Un noeud pour la liste chainée.
    """
    def __init__(self, data):
        self.data = data
        self.next = None

    def __repr__(self):
        return f"Node({self.data})"


class LinkedList:
    """
    Représente une Liste chaînée (Linked List) simple.
    """
    def __init__(self):
        self.head = None

    def search(self, element):
        """Rechercher un élément"""
        current = self.head
        position = 0
        while current:
            if current.data == element:
                return position
            current = current.next
            position += 1
        return -1

    def insert(self, element, position=None):
        """
        Insérer un élément.
        Si position vaut None, insère à la fin de la liste.
        La position commence à l'index 0.
        """
        new_node = ListNode(element)
        
        if self.head is None:
            if position is not None and position > 0:
                raise IndexError("Index hors limites")
            self.head = new_node
            return

        if position == 0:
            new_node.next = self.head
            self.head = new_node
            return

        current = self.head
        index = 0
        while current.next and (position is None or index < position - 1):
            current = current.next
            index += 1

        if position is not None and index < position - 1:
            raise IndexError("Index hors limites")

        new_node.next = current.next
        current.next = new_node

    def delete(self, element):
        """Supprimer le premier élément qui correspond à 'element'"""
        if self.head is None:
            return False
            
        if self.head.data == element:
            self.head = self.head.next
            return True
            
        current = self.head
        while current.next:
            if current.next.data == element:
                current.next = current.next.next
                return True
            current = current.next
            
        return False

    def __repr__(self):
        elements = []
        current = self.head
        while current:
            elements.append(str(current.data))
            current = current.next
        return " -> ".join(elements) if elements else "Liste chaînée vide"
