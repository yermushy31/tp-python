class Node:
    """
    Représente un sommet (noeud) dans un arbre binaire.
    """
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

    def __repr__(self):
        return f"Node({self.value})"


def create_binary_tree(n):
    """
    Crée un arbre binaire basique avec n sommets numérotés (de 1 à n).
    L'arbre est construit uniformément, niveau par niveau.
    Retourne le noeud racine de l'arbre binaire.
    """
    if n <= 0: # si n est inférieur ou égal à 0, on retourne None
        return None
    
    nodes = [Node(i) for i in range(1, n + 1)] # on crée une liste de noeuds avec les valeurs de 1 à n
    
    for i in range(1, n + 1): # on parcourt la liste de noeuds
        left_index = 2 * i # formule spécifique aux arbres binaires
        right_index = 2 * i + 1 # formule spécifique aux arbres binaires
        
        if left_index <= n: # on vérifie que l'indice est dans les limites du tableau
            nodes[i - 1].left = nodes[left_index - 1] # on utilise i - 1 car les indices commencent à 0
        if right_index <= n: # on vérifie que l'indice est dans les limites du tableau
            nodes[i - 1].right = nodes[right_index - 1] # on utilise i - 1 car les indices commencent à 0
            
    return nodes[0]


def breadth_first_search(root):
    """
    Retourne une liste de sommets dans l'ordre du parcours en largeur (breadth-first).
    """
    if root is None:
        return []
        
    result = []
    queue = [root]
    
    while queue:
        current = queue.pop(0)
        result.append(current.value)
        if current.left:
            queue.append(current.left)
        if current.right:
            queue.append(current.right)
            
    return result


def pre_order(root):
    """
    Retourne une liste de sommets dans l'ordre du parcours préfixe.
    Ordre : Élément racine -> Branche gauche -> Branche droite
    """
    if root is None:
        return []
        
    result = [root.value]
    result.extend(pre_order(root.left))
    result.extend(pre_order(root.right))
    return result


def in_order(root):
    """
    Retourne une liste de sommets dans l'ordre du parcours infixe.
    Ordre : Branche gauche -> Élément racine -> Branche droite
    """
    if root is None:
        return []
        
    result = in_order(root.left)
    result.append(root.value)
    result.extend(in_order(root.right))
    return result


def post_order(root):
    """
    Retourne une liste de sommets dans l'ordre du parcours postfixe.
    Ordre : Branche gauche -> Branche droite -> Élément racine
    """
    if root is None:
        return []
        
    result = post_order(root.left)
    result.extend(post_order(root.right))
    result.append(root.value)
    return result


def insert_leaf(root, parent_value, new_value, direction):
    """
    Insère une simple feuille dans l'arbre sous une valeur de parent spécifiée.
    direction doit être soit 'left' (gauche), soit 'right' (droite).
    Retourne True si l'opération a réussi, False si le parent n'est pas trouvé ou si la position est déjà prise.
    """
    if root is None:
        return False
        
    queue = [root] # on crée une file avec la racine
    target_node = None # on initialise le noeud cible à None
    
    while queue: # on parcourt la file
        current = queue.pop(0) # on retire le premier élément de la file
        if current.value == parent_value: # si la valeur de l'élément est égale à la valeur du parent
            target_node = current # on assigne l'élément au noeud cible
            break # on sort de la boucle
        if current.left: # si l'élément a un fils gauche
            queue.append(current.left) # on ajoute le fils gauche à la file
        if current.right: # si l'élément a un fils droit
            queue.append(current.right) # on ajoute le fils droit à la file
            
    if target_node is None:
        return False
        
    if direction == 'left' and target_node.left is None:
        target_node.left = Node(new_value)
        return True
    elif direction == 'right' and target_node.right is None:
        target_node.right = Node(new_value)
        return True
        
    return False


def insert_branch(root, parent_value, subtree_root, direction):
    """
    Insère une branche entière (sous-arbre) dans l'arbre sous un parent spécifié.
    direction doit être soit 'left' (gauche), soit 'right' (droite).
    Retourne True si l'opération a réussi, False si le parent n'est pas trouvé ou si la position est déjà prise.
    """
    if root is None:
        return False
        
    queue = [root]
    target_node = None
    
    while queue:
        current = queue.pop(0)
        if current.value == parent_value:
            target_node = current
            break
        if current.left:
            queue.append(current.left)
        if current.right:
            queue.append(current.right)
            
    if target_node is None:
        return False
        
    if direction == 'left' and target_node.left is None:
        target_node.left = subtree_root
        return True
    elif direction == 'right' and target_node.right is None:
        target_node.right = subtree_root
        return True
        
    return False
