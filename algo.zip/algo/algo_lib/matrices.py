def create_5x4_matrix():
    """
    Créer une fonction de création d'une matrice 5 x 4.
    Retourne une matrice de 5 lignes et 4 colonnes initialisées avec des 0.
    """
    return [[0 for _ in range(4)] for _ in range(5)]


def create_nxm_matrix(n, m):
    """
    Créer une fonction de création d'une matrice n x m.
    Retourne une matrice de n lignes et m colonnes initialisées avec des 0.
    """
    if n <= 0 or m <= 0:
        return []
    return [[0 for _ in range(m)] for _ in range(n)]


def are_identically_shaped(mat1, mat2):
    """
    Fonction utilitaire pour vérifier si deux matrices ont exactement les mêmes dimensions.
    """
    if not mat1 or not mat2:
        return False
    return len(mat1) == len(mat2) and len(mat1[0]) == len(mat2[0])


def can_be_multiplied(mat1, mat2):
    """
    Fonction utilitaire pour vérifier si deux matrices peuvent être mathématiquement multipliées (produit matriciel).
    Règle : colonnes de mat1 == lignes de mat2
    """
    if not mat1 or not mat2:
        return False
    return len(mat1[0]) == len(mat2)


def add_matrices(mat1, mat2):
    """
    Addition de deux matrices compatibles.
    """
    if not are_identically_shaped(mat1, mat2):
        raise ValueError("Les matrices n'ont pas des formes identiques pour l'addition")
    
    n = len(mat1)
    m = len(mat1[0])
    result = create_nxm_matrix(n, m)
    
    for i in range(n):
        for j in range(m):
            result[i][j] = mat1[i][j] + mat2[i][j]
    return result


def multiply_matrices(mat1, mat2):
    """
    Multiplication de matrices standard (produit des lignes et des colonnes).
    """
    if not can_be_multiplied(mat1, mat2):
        raise ValueError("Les matrices ne sont pas compatibles pour une multiplication standard")
        
    n = len(mat1)
    m = len(mat1[0])
    p = len(mat2[0])
    
    result = create_nxm_matrix(n, p)
    
    for i in range(n):
        for j in range(p):
            for k in range(m):
                result[i][j] += mat1[i][k] * mat2[k][j]
                
    return result


def apply_operation(mat1, mat2, operation):
    """
    Créer une fonction standard avec paramètre précisant l'opération à réaliser 
    (+, -, /, x) avec deux matrices compatibles.
    Gestion de règle spéciale : division par 0 -> 1 (! à /0 -> = 1)
    """
    if not are_identically_shaped(mat1, mat2):
        raise ValueError("Les matrices n'ont pas des formes identiques pour ces opérations")
        
    n = len(mat1)
    m = len(mat1[0])
    result = create_nxm_matrix(n, m)
    
    for i in range(n):
        for j in range(m):
            a = mat1[i][j]
            b = mat2[i][j]
            
            if operation == '+':
                result[i][j] = a + b
            elif operation == '-':
                result[i][j] = a - b
            elif operation == 'x' or operation == '*':
                result[i][j] = a * b
            elif operation == '/':
                if b == 0:
                    result[i][j] = 1
                else:
                    result[i][j] = a / b
            else:
                raise ValueError(f"Opération '{operation}' non supportée. Utilisez +, -, x ou /")
                
    return result


def print_matrix(mat):
    """
    Fonction utilitaire pour imprimer visuellement une matrice.
    """
    if not mat:
        print("Matrice vide")
        return
        
    for row in mat:
        print("[\t" + "\t".join(str(val) for val in row) + "\t]")
