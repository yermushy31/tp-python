#!/usr/bin/env bash
# =============================================================================
# Script de déploiement — Environnement ML/DL
# =============================================================================
# Usage : ./scripts/deploy.sh
# Ce script vérifie les prérequis, build l'image Docker et lance l'environnement.
# =============================================================================

set -euo pipefail

# ── Couleurs ─────────────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[OK]${NC} $1"; }
warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

# ── Vérification des prérequis ──────────────────────────────────────────────
info "Vérification des prérequis..."

if ! command -v docker &> /dev/null; then
    error "Docker n'est pas installé. Installez-le : https://docs.docker.com/get-docker/"
fi
success "Docker $(docker --version | awk '{print $3}') détecté"

if ! command -v docker compose &> /dev/null && ! command -v docker-compose &> /dev/null; then
    error "Docker Compose n'est pas installé."
fi
success "Docker Compose détecté"

if ! docker info &> /dev/null; then
    error "Le daemon Docker n'est pas démarré. Lancez : sudo systemctl start docker"
fi
success "Docker daemon actif"

# ── Détermination du répertoire du projet ────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

info "Répertoire du projet : $PROJECT_DIR"
cd "$PROJECT_DIR"

# ── Build de l'image Docker ─────────────────────────────────────────────────
info "Construction de l'image Docker..."
docker compose build --no-cache

success "Image construite avec succès"

# ── Lancement du conteneur ──────────────────────────────────────────────────
info "Lancement de l'environnement..."
docker compose up -d

success "Environnement démarré !"
echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}  Jupyter Lab disponible sur : http://localhost:8888  ${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo "Commandes utiles :"
echo "  docker compose exec ml-env make quality   # Checks de qualité"
echo "  docker compose exec ml-env make test       # Tests unitaires"
echo "  docker compose exec ml-env bash            # Shell interactif"
echo "  docker compose logs -f                     # Logs en temps réel"
echo "  docker compose down                        # Arrêter l'environnement"
